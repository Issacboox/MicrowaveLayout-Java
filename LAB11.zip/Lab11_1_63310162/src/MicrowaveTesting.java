public class MicrowaveTesting {
	public static void main(String[] args) {
		Microwave myMicrowave = new Microwave();
	}
}
